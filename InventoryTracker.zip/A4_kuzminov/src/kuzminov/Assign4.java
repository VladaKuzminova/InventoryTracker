package kuzminov;

//import java.util.Scanner;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author $ Vlada Kuzminova
 */
public class Assign4 extends Application {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Application.launch(args);

    }

    @Override
    public void start(Stage stage) throws Exception {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.

        Parent root = FXMLLoader.load(getClass().getResource("Assign4FXML.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);

        stage.setTitle("Assignment 4 Vlada Kuzminova");
        stage.show();

        String stylesheet = getClass().getResource("A4_CSS.css").toExternalForm();
        scene.getStylesheets().add(stylesheet);

    }

}
