/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuzminov;

import java.util.ArrayList;

/**
 * this class generates a invList ArrayList
 *
 * @author Vlada Kuzminova
 */
public class InventoryList {

    private ArrayList<Inventory> invList;

    /**
     * default InventoryList constructor
     */
    public InventoryList() {

    }

    /**
     * add method which allows to add inventory objects to the ArrayList
     *
     * @param i1
     */
    public void add(Inventory i1) {
        invList.add(i1);

    }

    /**
     * get method which allows to access index of the inventory objects inside
     * ArrayList
     *
     * @param index
     * @return
     */
    public Inventory get(int index) {
        return invList.get(index);
    }

    /**
     * length method which returns the size on the ArrayList
     *
     * @return
     */
    public int length() {
        return invList.size();
    }
}
