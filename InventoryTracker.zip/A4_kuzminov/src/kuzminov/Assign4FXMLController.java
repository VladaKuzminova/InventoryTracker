/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuzminov;

import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Vlada Kuzminova
 */
public class Assign4FXMLController implements Initializable {

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    /**
     * All the items used in this program
     */
    @FXML
    private TextField txtId, txtName, txtQOH, txtROP, txtPrice;

    @FXML
    private Button btnSave, btnAdd, btnExit, btnOrder;

    @FXML
    private Label lblId, lblName, lblQOH, lblROP, lblPrice, lblMessage;

    @FXML
    private ArrayList<Inventory> invList;

    @FXML
    private Inventory i1;

    @FXML
    private TextField[] array;

    @FXML
    private ListView<Inventory> lstReOrderListView;

    @FXML
    private ObservableList<Inventory> obsInventory;

    @FXML
    private boolean h;

    /**
     * initialize method used to initialize all the items
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        lblId.setText(Fields.ITEM_ID.getCaption() + ":");
        lblName.setText(Fields.ITEM_NAME.getCaption() + ":");
        lblQOH.setText(Fields.QOH.getCaption() + ":");
        lblROP.setText(Fields.ROP.getCaption() + ":");
        lblPrice.setText(Fields.PRICE.getCaption() + ":");
        boolean h;
        invList = new ArrayList();
        /**
         * eventHandler for ADD button uses add method
         */
        btnAdd.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent a) {
                add();
            }

        });
        /**
         * eventHandler for SAVE button uses alerts method to handle errors
         * makes observable list
         */
        btnSave.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent s) {

                Inventory i1 = new Inventory();
                i1.setId(txtId.getText());
                i1.setName(txtName.getText());
                i1.setQoh(Integer.parseInt(txtQOH.getText()));
                i1.setRop(Integer.parseInt(txtROP.getText()));
                i1.setSellPrice(Double.parseDouble(txtPrice.getText()));

                if (alerts()) {
                    invList.add(i1);
                    add();
                }

                btnOrder.setDisable(false);

                obsInventory = FXCollections.observableArrayList();
                for (int i = 0; i < invList.size(); i++) {
                    obsInventory.add(invList.get(i));
                }
            }
        });
        /**
         * eventHandler for ORDER button uses eventHandler for the observable
         * list displays re-order point value of the clicked item inside the
         * listView
         */
        btnOrder.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent s) {
                if (invList.isEmpty()) {
                    lblMessage.setText("No orders. Add some.");
                } else {
                    lstReOrderListView.setItems(obsInventory);
                    lblMessage.setText("");
                }
                lstReOrderListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
                lstReOrderListView.getSelectionModel().selectedItemProperty().addListener((Observable o) -> {
                    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                    int p = lstReOrderListView.getSelectionModel().getSelectedItem().getRop();
                    lblMessage.setText("Re-order Point: " + p);
                    lblMessage.setStyle("-fx-text-fill: black");
                });
            }

        });
        /**
         * eventHandler for EXIT button uses alert dialog used to exit the
         * program
         */
        btnExit.setOnAction((ActionEvent t) -> {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            Alert alert2 = new Alert(Alert.AlertType.CONFIRMATION);
            alert2.setTitle("Exit");
            alert2.setHeaderText("Are You Sure You Want To Exit?");
            alert2.getButtonTypes().remove(ButtonType.OK);
            alert2.getButtonTypes().add(ButtonType.YES);
            alert2.getButtonTypes().remove(ButtonType.CANCEL);
            alert2.getButtonTypes().add(ButtonType.NO);

            Optional<ButtonType> result = alert2.showAndWait();
            if (result.get() == ButtonType.YES) {
                System.exit(0);
            }
        });

    }

    /**
     * add method which is used in ADD button eventHandler
     */
    @FXML
    private void add() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        txtId.requestFocus();

        TextField[] array1 = new TextField[5];
        array1[0] = txtId;
        array1[1] = txtName;
        array1[2] = txtQOH;
        array1[3] = txtROP;
        array1[4] = txtPrice;
        for (int i = 0; i < array1.length; i++) {
            array1[i].setEditable(true);
            array1[i].clear();
        }

        btnSave.setDisable(false);
        btnAdd.setDisable(true);
        btnOrder.setDisable(true);
    }

    /**
     * alerts method used in SAVE button eventHandler handles the errors using
     * alert dialogs
     *
     * @return
     */
    @FXML
    public boolean alerts() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("ERROR");
        alert.setHeaderText("INVALID INPUT");
        h = true;
        if (!txtId.getText().matches("[a-zA-Z]{3}-[\\d]{4}")) {
            alert.setContentText("Error: Inventory ID must be in a form ABC-1234!");
            alert.showAndWait();
            txtId.clear();
            h = false;
        } else if (txtName.getText().isEmpty()) {
            alert.setContentText("Error: you must enter an item name!");
            alert.showAndWait();
            txtName.clear();
            h = false;
        } else if (Integer.parseInt(txtQOH.getText()) < 0) {
            String a = "Error: Quantity on Hand cannot be less than 0";
            String b = "and must have an integer value!";
            alert.setContentText(a + "\n" + b);
            alert.showAndWait();
            txtQOH.clear();
            h = false;
        } else if (Integer.parseInt(txtROP.getText()) < 0) {
            alert.setContentText("Error: Re-order Point cannot be less than 0 and must have an integer value!");
            String a = "Error: Re-order Point cannot be less than 0";
            String b = "and must have an integer value!";
            alert.setContentText(a + "\n" + b);
            alert.showAndWait();
            txtROP.clear();
            h = false;
        } else if (Double.parseDouble(txtPrice.getText()) < 0) {
            alert.setContentText("Error: Unit Price cannot be less than 0 and must have an integer or double value!");
            String a = "Error: Unit Price cannot be less than 0";
            String b = "and must have an integer or double value!";
            alert.setContentText(a + "\n" + b);
            alert.showAndWait();
            txtPrice.clear();
            h = false;
        }
        return h;
    }

}
