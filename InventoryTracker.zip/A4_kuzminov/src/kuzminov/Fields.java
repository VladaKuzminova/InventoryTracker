/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuzminov;

/**
 * This is Enum class called Fields It allows to refer to the label using
 * caption variable
 *
 * @author Vlada Kuzminova
 */
public enum Fields {
    ITEM_ID("Inventory ID"),
    ITEM_NAME("Item Name"),
    QOH("Qty-On-Hand"),
    ROP("Re-Order Point"),
    PRICE("Unit Price");

    private final String caption;

    /**
     * Fields constructor
     *
     * @param caption
     */
    private Fields(String caption) {
        this.caption = caption;
    }

    /**
     * getter to access caption variable
     *
     * @return
     */
    public String getCaption() {
        return caption;
    }
}
