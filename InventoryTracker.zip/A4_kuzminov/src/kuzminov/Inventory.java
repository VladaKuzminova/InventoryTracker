/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuzminov;

import java.util.Scanner;

/**
 *
 * @author Vlada Kuzminova
 */
public class Inventory {

    Scanner input = new Scanner(System.in);
    private String id;
    private String name;
    private int qoh;
    private int rop;
    private double sellPrice;

    /**
     * This is a constructor which is setting all the variables to their default
     * values
     */
    public Inventory() {

        id = "ABC-1234";
        name = "New Item";
        qoh = 0;
        rop = 25;
        sellPrice = 0.0;

    }

    /**
     *
     * @param id
     * @param name
     * @param qoh
     * @param rop
     * @param sellPrice
     */
    public Inventory(String id, String name, int qoh, int rop, double sellPrice) {
        this.id = id;
        this.name = name;
        this.qoh = qoh;
        this.rop = rop;
        this.sellPrice = sellPrice;

    }

    /**
     *
     * @param id
     * @param name
     * @param sellPrice
     */
    public Inventory(String id, String name, double sellPrice) {
        this.id = id;
        this.name = name;
        this.sellPrice = sellPrice;

    }

    /**
     * This method allows setter to access the id variable
     *
     * @return
     */
    public String getId() {

        return id;

    }

    /**
     * This is a setter method which checks if the user input is valid
     *
     * @param id
     */
    public final void setId(String id) {
        try {
            if (!id.matches("[a-zA-Z]{3}-[\\d]{4}")) {
                System.out.println("Error: Inventory ID must be in the form ABC-1234");
            } else {
                this.id = id;
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: Inventory ID must be in the form ABC-1234");
        }

    }

    /**
     * This method allows setter to access the Name variable
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * This is a setter method which checks if the user input is valid
     *
     * @param name
     */
    public final void setName(String name) {
        try {
            if (!name.isEmpty() || null != name) {
                this.name = name;
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: you must enter an item name.");
        }

    }

    /**
     * This method allows setter to access the Quantity on Hand (qoh) variable
     *
     * @return
     */
    public int getQoh() {

        return qoh;
    }

    /**
     * This is a setter method which checks if the user input is valid
     *
     * @param qoh
     */
    public final void setQoh(int qoh) {
        try {
            if (qoh >= 0) {
                this.qoh = qoh;
            } else {
                System.out.println("Error: Quantity on Hand cannot be less than 0");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: Quantity on Hand cannot be less than 0");
        }
    }

    /**
     * This method allows setter to access the Re-Order Point (rop) variable
     *
     * @return
     */
    public int getRop() {

        return rop;

    }

    /**
     * This is a setter method which checks if the user input is valid
     *
     * @param rop
     */
    public final void setRop(int rop) {
        try {
            if (rop > 0) {
                this.rop = rop;
            } else {
                System.out.println("Error: Re-order Point must be greater than 0");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: Re-order Point must be greater than 0");
        }

    }

    /**
     * This method allows setter to access the sellPrice variable
     *
     * @return
     */
    public double getSellPrice() {

        return sellPrice;
    }

    /**
     * This is a setter method which checks if the user input is valid
     *
     * @param sellPrice
     */
    public final void setSellPrice(double sellPrice) {
        try {
            if (sellPrice >= 0) {
                this.sellPrice = sellPrice;
            } else {
                System.out.println("Error: Selling price must be greater than 0.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Error: Selling price must be greater than 0.");
        }
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        String a = String.format("%s (%s), QOH:%d, Price: $%.2f", id, name, qoh, sellPrice);
        return a;
    }
}
